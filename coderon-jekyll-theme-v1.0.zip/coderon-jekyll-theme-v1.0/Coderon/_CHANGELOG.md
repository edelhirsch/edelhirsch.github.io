## [1.0.0] - 2025-01-27

- Initial Release